# ============================================================
# CRITICAL: MediaPipe must be imported FIRST before Panda3D or Pygame.
# On Windows, importing Panda3D/OpenGL/Pygame before MediaPipe causes a
# C++ runtime DLL collision in _framework_bindings.pyd ("DLL initialization routine failed").
# ============================================================
try:
    import mediapipe as mp
    _mp_import_error = None
except Exception as _e:
    mp = None
    _mp_import_error = _e

import math
import time
import os
import sys

from direct.showbase.ShowBase import ShowBase
from panda3d.core import (
    WindowProperties,
    TextNode,
    AmbientLight,
    DirectionalLight,
    Point3,
    Vec4
)

# HoloHand AI Subsystems
from core.camera import Camera
from core.hand_tracker import HandTracker
from core.gesture_engine import GestureEngine
from core.sound_manager import SoundManager
from hand3d.hand_model import HandModel
from interface.home import Home
from music.piano.piano import Piano
from music.drums.drums import Drums


# ============================================================
# HOLOHAND AI — SPATIAL NEURAL INTERACTION SYSTEM
# ============================================================

class HoloHandApp(ShowBase):

    def __init__(self):
        ShowBase.__init__(self)

        print("")
        print("============================================================")
        print("           HOLOHAND AI — SYSTEM BOOT SEQUENCE")
        print("============================================================")

        # ----------------------------------------------------
        # WINDOW PROPERTIES
        # ----------------------------------------------------
        if hasattr(self.win, "requestProperties"):
            properties = WindowProperties()
            properties.setSize(1280, 720)
            properties.setTitle("HoloHand AI — Spatial Neural Interaction System")
            properties.setCursorHidden(False)
            self.win.requestProperties(properties)

        # ----------------------------------------------------
        # 3D WORLD & LIGHTING
        # ----------------------------------------------------
        self.setup_3d_world()

        # ----------------------------------------------------
        # CAMERA SENSOR (HIDDEN BACKGROUND INPUT)
        # ----------------------------------------------------
        self.camera_sensor = Camera(width=640, height=480)
        if self.camera_sensor.is_opened():
            print("Sensor Status:      ONLINE (Background Camera Sensor Active)")
        else:
            print("Sensor Status:      OFFLINE (Camera could not be opened)")

        # ----------------------------------------------------
        # MEDIAPIPE HAND TRACKER
        # ----------------------------------------------------
        self.hand_tracker = HandTracker(
            max_hands=1,
            detection_confidence=0.55,
            tracking_confidence=0.55
        )

        # ----------------------------------------------------
        # GESTURE ENGINE (WITH STABILITY DEBOUNCING)
        # ----------------------------------------------------
        self.gesture_engine = GestureEngine(stable_frames=7)
        self.last_mode_switch_time = 0
        self.mode_switch_cooldown = 1.0  # Prevents rapid erratic mode flipping

        # ----------------------------------------------------
        # AUDIO SUBSYSTEM
        # ----------------------------------------------------
        self.sound_manager = SoundManager()

        # ----------------------------------------------------
        # 3D HOLOGRAPHIC HAND RENDERER
        # ----------------------------------------------------
        self.hand_model = HandModel(self)
        print("3D Holo Renderer:   ONLINE (Volumetric 3D Hull & Phalanges)")

        # ----------------------------------------------------
        # USER INTERFACES
        # ----------------------------------------------------
        self.home_ui = Home(self, on_mode_select=self.set_mode)
        self.piano_ui = Piano(self, self.sound_manager)
        self.drums_ui = Drums(self, self.sound_manager)
        print("UI Subsystem:       ONLINE (Spatial Glass HUD & Telemetry)")

        # ----------------------------------------------------
        # APPLICATION STATE
        # ----------------------------------------------------
        self.mode = "HOME"
        self.hand_detected = False
        self.active_gesture = "UNKNOWN"

        # Show initial Home screen
        self.set_mode("HOME")

        # ----------------------------------------------------
        # KEYBOARD SHORTCUTS
        # ----------------------------------------------------
        self.accept("1", self.set_mode, ["HOME"])
        self.accept("h", self.set_mode, ["HOME"])
        self.accept("2", self.set_mode, ["PIANO"])
        self.accept("p", self.set_mode, ["PIANO"])
        self.accept("3", self.set_mode, ["DRUMS"])
        self.accept("d", self.set_mode, ["DRUMS"])
        self.accept("escape", self.exit_app)

        # ----------------------------------------------------
        # MAIN UPDATE TASK
        # ----------------------------------------------------
        self.taskMgr.add(self.update, "HoloHandMainUpdate")

        # ----------------------------------------------------
        # SYSTEM READY BANNER
        # ----------------------------------------------------
        print("============================================================")
        print("           HOLOHAND AI IS ONLINE & READY")
        print("============================================================")
        print("GESTURE PROTOCOLS:")
        print("  OPEN PALM    --> HOME CORE")
        print("  TWO FINGERS  --> CYBER PIANO LAB")
        print("  CLOSED FIST  --> RHYTHM DRUM MATRIX")
        print("  PINCH        --> SPATIAL SELECT")
        print("============================================================")
        print("")

    # ========================================================
    # 3D ENVIRONMENT SETUP & CINEMATIC LIGHTING
    # ========================================================

    def setup_3d_world(self):
        # Sci-Fi Deep Space Dark Holographic Background
        self.setBackgroundColor(0.008, 0.012, 0.022, 1.0)

        # Camera Position & Perspective
        self.camera.setPos(0, -12, 0.4)
        self.camera.lookAt(Point3(0, 0, 0.4))

        # Ambient Cyber Lighting
        ambient = AmbientLight("HoloAmbient")
        ambient.setColor(Vec4(0.25, 0.38, 0.55, 1.0))
        ambient_node = self.render.attachNewNode(ambient)
        self.render.setLight(ambient_node)

        # Key Directional Cyan Lighting
        directional_key = DirectionalLight("HoloKeyLight")
        directional_key.setColor(Vec4(0.45, 0.90, 1.0, 1.0))
        key_node = self.render.attachNewNode(directional_key)
        key_node.setHpr(-35, -30, 0)
        self.render.setLight(key_node)

        # Rim Directional Purple Accent Lighting
        directional_rim = DirectionalLight("HoloRimLight")
        directional_rim.setColor(Vec4(0.55, 0.20, 0.90, 1.0))
        rim_node = self.render.attachNewNode(directional_rim)
        rim_node.setHpr(45, 30, 0)
        self.render.setLight(rim_node)

    # ========================================================
    # MODE SWITCHING & NAVIGATION
    # ========================================================

    def set_mode(self, mode):
        self.mode = mode
        print(f"HoloHand Mode Activated: [ {mode} ]")

        if mode == "HOME":
            self.home_ui.show()
            self.piano_ui.hide()
            self.drums_ui.hide()
        elif mode == "PIANO":
            self.home_ui.hide()
            self.piano_ui.show()
            self.drums_ui.hide()
        elif mode == "DRUMS":
            self.home_ui.hide()
            self.piano_ui.hide()
            self.drums_ui.show()

    # ========================================================
    # GESTURE-BASED NAVIGATION
    # ========================================================

    def handle_gestures(self, gesture):
        now = time.time()
        if now - self.last_mode_switch_time < self.mode_switch_cooldown:
            return

        target_mode = None
        if gesture == "OPEN PALM":
            target_mode = "HOME"
        elif gesture == "TWO FINGERS":
            target_mode = "PIANO"
        elif gesture == "CLOSED FIST":
            target_mode = "DRUMS"

        if target_mode and target_mode != self.mode:
            self.set_mode(target_mode)
            self.last_mode_switch_time = now

    # ========================================================
    # MAIN LOOP (CONTINUOUS UPDATE PER FRAME)
    # ========================================================

    def update(self, task):
        # 1. Read frame from background camera sensor (completely hidden)
        frame = self.camera_sensor.read()
        if frame is None:
            self.hand_detected = False
            self.active_gesture = "UNKNOWN"
            # Maintain canonical hovering idle hand
            self.hand_model.update(None)
            self._update_active_mode(None)
            if self.mode == "HOME":
                self.home_ui.update_telemetry(False, "WAITING FOR HAND", self.mode, confidence=0.0)
            return task.cont

        # 2. Process frame with MediaPipe HandTracker
        detected_hands = self.hand_tracker.process(frame)

        # 3. Check if hand is in field
        if detected_hands:
            self.hand_detected = True
            primary_hand = detected_hands[0]

            # Update 3D Volumetric Holographic Hand in spatial scene
            self.hand_model.update(primary_hand)

            # Detect debounced gesture
            self.active_gesture = self.gesture_engine.update(primary_hand)

            # Check if gesture triggers a mode transition
            self.handle_gestures(self.active_gesture)

            # Update active experience
            self._update_active_mode(primary_hand)

            # Update Home HUD telemetry
            if self.mode == "HOME":
                status = self.gesture_engine.get_status()
                self.home_ui.update_telemetry(True, self.active_gesture, self.mode, confidence=status["confidence"])

        else:
            self.hand_detected = False
            self.active_gesture = "UNKNOWN"

            # Smoothly transition 3D hand into canonical idle hovering state
            self.hand_model.update(None)

            # Update active experience with no hand
            self._update_active_mode(None)

            # Update Home HUD telemetry
            if self.mode == "HOME":
                self.home_ui.update_telemetry(False, "WAITING FOR HAND", self.mode, confidence=0.0)

        return task.cont

    def _update_active_mode(self, hand):
        """Passes tracking data to the currently active experience."""
        if self.mode == "PIANO":
            self.piano_ui.update(hand)
        elif self.mode == "DRUMS":
            self.drums_ui.update(hand)

    # ========================================================
    # CLEANUP & EXIT
    # ========================================================

    def exit_app(self):
        self.userExit()

    def cleanup(self):
        print("Terminating HoloHand AI Subsystems...")
        try:
            self.camera_sensor.release()
        except Exception:
            pass

        try:
            self.hand_tracker.close()
        except Exception:
            pass

        try:
            self.sound_manager.close()
        except Exception:
            pass

        try:
            self.hand_model.cleanup()
        except Exception:
            pass

        try:
            self.home_ui.cleanup()
            self.piano_ui.cleanup()
            self.drums_ui.cleanup()
        except Exception:
            pass
        print("HoloHand AI Shutdown Complete.")


# ============================================================
# START APPLICATION ENTRYPOINT
# ============================================================

if __name__ == "__main__":
    app = None

    try:
        app = HoloHandApp()
        app.run()

    except Exception as error:
        print("")
        print("============================================================")
        print("HOLOHAND AI RUNTIME ERROR")
        print("============================================================")
        print(f"{type(error).__name__}: {error}")
        import traceback
        traceback.print_exc()
        print("============================================================")

    finally:
        if app is not None:
            app.cleanup()