import os
import cv2
import mediapipe as mp


class HandLandmarksWrapper:
    """Compatibility wrapper that provides .landmark list attribute like legacy MediaPipe."""

    def __init__(self, landmarks):
        self.landmark = landmarks

    def __iter__(self):
        return iter(self.landmark)

    def __getitem__(self, index):
        return self.landmark[index]

    def __len__(self):
        return len(self.landmark)


class HandTracker:

    def __init__(
        self,
        max_hands=2,
        detection_confidence=0.5,
        tracking_confidence=0.5
    ):
        self.max_hands = max_hands
        self.detection_confidence = detection_confidence
        self.tracking_confidence = tracking_confidence
        self.mode = None
        self.detector = None
        self.hands = None

        if mp is None:
            print("MediaPipe Hand Tracker: SKIPPED (mediapipe module not available)")
            return

        # 1. First check if modern MediaPipe Tasks API is available (mediapipe >= 0.10.x / 1.x)
        if hasattr(mp, "tasks") and hasattr(mp.tasks, "vision"):
            try:
                model_path = self._get_model_path()
                if model_path and os.path.exists(model_path):
                    base_options = mp.tasks.BaseOptions(model_asset_path=model_path)
                    options = mp.tasks.vision.HandLandmarkerOptions(
                        base_options=base_options,
                        num_hands=max_hands,
                        min_hand_detection_confidence=detection_confidence,
                        min_hand_presence_confidence=detection_confidence,
                        min_tracking_confidence=tracking_confidence,
                        running_mode=mp.tasks.vision.RunningMode.IMAGE
                    )
                    self.detector = mp.tasks.vision.HandLandmarker.create_from_options(options)
                    self.mode = "tasks"
                    print("MediaPipe Hand Tracker: READY (MediaPipe Tasks Landmarker)")
                    return
                else:
                    print(f"MediaPipe Tasks: Model file not accessible at {model_path}")
            except Exception as e:
                print(f"MediaPipe Tasks initialization failed: {e}")

        # 2. Fallback to legacy mp.solutions.hands if present
        if hasattr(mp, "solutions") and hasattr(mp.solutions, "hands"):
            try:
                self.hands = mp.solutions.hands.Hands(
                    static_image_mode=False,
                    max_num_hands=max_hands,
                    min_detection_confidence=detection_confidence,
                    min_tracking_confidence=tracking_confidence,
                    model_complexity=1
                )
                self.mode = "legacy"
                print("MediaPipe Hand Tracker: READY (MediaPipe Solutions)")
                return
            except Exception as error:
                print("MediaPipe Hand Tracker (Legacy) ERROR:", error)

        print("MediaPipe Hand Tracker ERROR: Unable to initialize MediaPipe hand tracker")

    def _get_model_path(self):
        """Locates or downloads hand_landmarker.task model."""
        project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
        model_dir = os.path.join(project_root, "models")
        model_path = os.path.join(model_dir, "hand_landmarker.task")

        if os.path.exists(model_path) and os.path.getsize(model_path) > 100000:
            return model_path

        # If not present or incomplete, download from official repository
        try:
            print("MediaPipe hand_landmarker.task model not found. Downloading...")
            os.makedirs(model_dir, exist_ok=True)
            import urllib.request
            url = "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/latest/hand_landmarker.task"
            urllib.request.urlretrieve(url, model_path)
            print("MediaPipe hand_landmarker.task model downloaded successfully.")
            return model_path
        except Exception as e:
            print("Failed to download MediaPipe model:", e)
            return None

    def process(self, frame):
        if frame is None:
            return []

        if self.mode == "tasks" and self.detector is not None:
            try:
                rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
                result = self.detector.detect(mp_image)
                if not result or not result.hand_landmarks:
                    return []
                return [HandLandmarksWrapper(lms) for lms in result.hand_landmarks]
            except Exception as error:
                print("Hand tracking error (Tasks):", error)
                return []

        elif self.mode == "legacy" and self.hands is not None:
            try:
                rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                rgb.flags.writeable = False
                result = self.hands.process(rgb)
                if not result or not result.multi_hand_landmarks:
                    return []
                return result.multi_hand_landmarks
            except Exception as error:
                print("Hand tracking error (Legacy):", error)
                return []

        return []

    def close(self):
        if self.detector is not None:
            try:
                self.detector.close()
            except Exception:
                pass
        if self.hands is not None:
            try:
                self.hands.close()
            except Exception:
                pass