import math
import time
from direct.gui.DirectGui import DirectFrame, DirectLabel
from panda3d.core import TextNode, Vec4, LineSegs, NodePath, Point3


class Piano:
    """
    Premium Holographic Cyber Piano Lab for HoloHand AI.

    Features:
      - 13 keys: 8 white (C4-C5) + 5 black (sharps/flats)
      - Index fingertip hover triggers notes (Y-zone aware)
      - Per-key neon glow with release fade
      - 3D orbiting octave rings in the 3D scene
      - Live note feedback display with octave shift support
      - Polyphonic audio via SoundManager
    """

    # White keys: C D E F G A B C5
    WHITE_KEYS = ["C", "D", "E", "F", "G", "A", "B", "C5"]
    WHITE_FREQS = {
        "C": 261.63, "D": 293.66, "E": 329.63, "F": 349.23,
        "G": 392.00, "A": 440.00, "B": 493.88, "C5": 523.25
    }

    # Black keys: (label, semitone_name, position between white key indices 0-based left edge)
    BLACK_KEYS = [
        {"label": "C#", "note": "Cs", "pos_after": 0},  # between C and D
        {"label": "D#", "note": "Ds", "pos_after": 1},  # between D and E
        # No black between E and F
        {"label": "F#", "note": "Fs", "pos_after": 3},  # between F and G
        {"label": "G#", "note": "Gs", "pos_after": 4},  # between G and A
        {"label": "A#", "note": "As", "pos_after": 5},  # between A and B
    ]

    def __init__(self, base, sound_manager):
        self.base = base
        self.sound_manager = sound_manager
        self._alive = True

        self.last_note = None
        self.last_time = 0
        self.cooldown = 0.22
        self.active_key_idx = None
        self.active_is_black = False
        self.pulse_phase = 0.0
        self.key_glow_timers = {}  # key_id -> last_hit_time

        # -- Build the 3D Piano World --
        self._build_piano_3d_world()

        # -- 2D HUD Overlay --
        self.frame = DirectFrame(
            frameColor=(0, 0, 0, 0),
            frameSize=(-1.77, 1.77, -1.0, 1.0),
            parent=self.base.aspect2d
        )

        self._build_header()
        self._build_note_display()
        self._build_white_keys()
        self._build_black_keys()
        self._build_info_bar()

        self.base.taskMgr.add(self._animate, "PianoAnimation")
        self.hide()

    # ====================================================
    # 3D PIANO WORLD
    # ====================================================

    def _build_piano_3d_world(self):
        """Floating piano energy rings in the 3D scene."""
        self.piano_world = NodePath("PianoWorld")
        self.piano_world.reparentTo(self.base.render)

        self.piano_rings = []
        configs = [
            (2.5, (0.2, 0.8, 1.0, 0.5), 2.5, (0, 20, 0)),
            (1.6, (0.6, 0.3, 1.0, 0.4), 1.8, (15, -10, 0)),
            (3.2, (0.1, 0.95, 0.7, 0.35), 1.4, (-10, 5, 0)),
        ]
        for radius, color, thick, tilt in configs:
            ring = self._make_ring(radius, color, thick)
            ring.reparentTo(self.piano_world)
            ring.setPos(0, 3.5, 0.3)
            ring.setHpr(*tilt)
            self.piano_rings.append(ring)

        # Piano staff lines (decorative 3D lines)
        lines = LineSegs("PianoStaff")
        lines.setThickness(1.2)
        for i in range(5):
            y_off = -0.8 + i * 0.4
            lines.setColor(0.15, 0.55, 0.9, 0.3)
            lines.moveTo(Point3(-4.0, 4.0, y_off))
            lines.drawTo(Point3(4.0, 4.0, y_off))
        geom = lines.create()
        staff = self.piano_world.attachNewNode(geom)

    def _make_ring(self, radius, color, thickness, segments=64):
        lines = LineSegs()
        lines.setThickness(thickness)
        lines.setColor(*color)
        for i in range(segments + 1):
            a = (i / segments) * math.pi * 2
            x, z = math.cos(a) * radius, math.sin(a) * radius
            if i == 0:
                lines.moveTo(Point3(x, 0, z))
            else:
                lines.drawTo(Point3(x, 0, z))
        return NodePath(lines.create())

    # ====================================================
    # HUD COMPONENTS
    # ====================================================

    def _build_header(self):
        self.title_banner = DirectFrame(
            parent=self.frame,
            frameColor=(0.01, 0.04, 0.12, 0.90),
            frameSize=(-0.80, 0.80, -0.075, 0.075),
            pos=(0, 0, 0.875)
        )
        self.title = DirectLabel(
            parent=self.title_banner,
            text="[+]  H O L O   P I A N O   L A B  [+]",
            scale=0.048,
            text_fg=Vec4(0.2, 0.95, 1.0, 1.0),
            text_align=TextNode.ACenter,
            relief=None,
            pos=(0, 0, 0.015)
        )
        self.instruction = DirectLabel(
            parent=self.title_banner,
            text="HOVER INDEX FINGERTIP  |  13 CHROMATIC KEYS  |  FULL OCTAVE C4-C5",
            scale=0.020,
            text_fg=Vec4(0.6, 0.8, 1.0, 0.85),
            text_align=TextNode.ACenter,
            relief=None,
            pos=(0, 0, -0.040)
        )

    def _build_note_display(self):
        self.note_display = DirectLabel(
            parent=self.frame,
            text="*  READY  --  POSITION FINGER OVER A KEY",
            scale=0.036,
            text_fg=Vec4(0.4, 1.0, 0.7, 1.0),
            text_align=TextNode.ACenter,
            relief=None,
            pos=(0, 0, 0.56)
        )
        self.octave_label = DirectLabel(
            parent=self.frame,
            text="OCTAVE 4  |  C D E F G A B C#  D#  F#  G#  A#",
            scale=0.022,
            text_fg=Vec4(0.5, 0.75, 1.0, 0.75),
            text_align=TextNode.ACenter,
            relief=None,
            pos=(0, 0, 0.50)
        )

    def _build_white_keys(self):
        """Build 8 white keys from C4 to C5."""
        self.white_key_frames = []
        self.white_key_labels = []

        key_w = 0.195
        key_h = 0.55
        gap = 0.015
        total_w = len(self.WHITE_KEYS) * (key_w + gap)
        start_x = -total_w / 2.0 + key_w / 2.0

        self.white_key_x = []
        self.white_key_w = key_w

        for i, note in enumerate(self.WHITE_KEYS):
            kx = start_x + i * (key_w + gap)
            ky = -0.18
            self.white_key_x.append(kx)

            frame = DirectFrame(
                parent=self.frame,
                frameColor=(0.04, 0.12, 0.24, 0.82),
                frameSize=(-key_w / 2.0, key_w / 2.0, -key_h / 2.0, key_h / 2.0),
                pos=(kx, 0, ky)
            )
            # Bottom note label
            label = DirectLabel(
                parent=frame,
                text=note,
                scale=0.042,
                text_fg=Vec4(0.7, 0.9, 1.0, 1.0),
                text_align=TextNode.ACenter,
                relief=None,
                pos=(0, 0, -key_h / 2.0 + 0.055)
            )
            self.white_key_frames.append(frame)
            self.white_key_labels.append(label)

    def _build_black_keys(self):
        """Build 5 black (sharp) keys floating above white keys."""
        self.black_key_frames = []
        self.black_key_labels = []

        key_w = 0.110
        key_h = 0.32
        gap = 0.015
        white_w = self.white_key_w + gap

        self.black_key_x = []

        for bk in self.BLACK_KEYS:
            wi = bk["pos_after"]
            # Center black key between white key wi and wi+1
            kx = self.white_key_x[wi] + white_w / 2.0
            ky = -0.18 + 0.14  # slightly higher (z) than white keys

            self.black_key_x.append(kx)

            frame = DirectFrame(
                parent=self.frame,
                frameColor=(0.55, 0.1, 0.8, 0.92),
                frameSize=(-key_w / 2.0, key_w / 2.0, -key_h / 2.0, key_h / 2.0),
                pos=(kx, 0, ky)
            )
            label = DirectLabel(
                parent=frame,
                text=bk["label"],
                scale=0.028,
                text_fg=Vec4(0.95, 0.9, 1.0, 1.0),
                text_align=TextNode.ACenter,
                relief=None,
                pos=(0, 0, -key_h / 2.0 + 0.04)
            )
            self.black_key_frames.append(frame)
            self.black_key_labels.append(label)

    def _build_info_bar(self):
        self.info_bar = DirectFrame(
            parent=self.frame,
            frameColor=(0.01, 0.03, 0.07, 0.80),
            frameSize=(-0.85, 0.85, -0.045, 0.045),
            pos=(0, 0, -0.84)
        )
        self.info_label = DirectLabel(
            parent=self.info_bar,
            text="[ H ] HOME  |  [ D ] DRUMS  |  [2 FINGERS] = PIANO  |  [OPEN PALM] = HOME",
            scale=0.022,
            text_fg=Vec4(0.5, 0.75, 1.0, 0.8),
            text_align=TextNode.ACenter,
            relief=None,
            pos=(0, 0, -0.010)
        )

    # ====================================================
    # ANIMATION TASK
    # ====================================================

    def _animate(self, task):
        if not self._alive:
            return task.done

        dt = globalClock.getDt()  # noqa
        self.pulse_phase = (self.pulse_phase + dt * 2.5) % (math.pi * 2)

        # Rotate 3D rings
        if hasattr(self, 'piano_world') and not self.piano_world.isEmpty():
            if len(self.piano_rings) >= 3:
                self.piano_rings[0].setH(self.piano_rings[0].getH() + dt * 35.0)
                self.piano_rings[1].setH(self.piano_rings[1].getH() - dt * 22.0)
                self.piano_rings[2].setH(self.piano_rings[2].getH() + dt * 50.0)
                self.piano_rings[2].setP(self.piano_rings[2].getP() + dt * 18.0)

        # Fade key glows after hit
        now = time.time()
        for i, f in enumerate(self.white_key_frames):
            key_id = f"w{i}"
            elapsed = now - self.key_glow_timers.get(key_id, 0)
            if elapsed < 0.3:
                glow = max(0.0, 1.0 - elapsed / 0.3)
                f["frameColor"] = (
                    0.04 + 0.15 * glow,
                    0.12 + 0.38 * glow,
                    0.24 + 0.65 * glow,
                    0.82 + 0.15 * glow
                )
            elif i != self.active_key_idx or self.active_is_black:
                f["frameColor"] = (0.04, 0.12, 0.24, 0.82)

        for i, f in enumerate(self.black_key_frames):
            key_id = f"b{i}"
            elapsed = now - self.key_glow_timers.get(key_id, 0)
            if elapsed < 0.3:
                glow = max(0.0, 1.0 - elapsed / 0.3)
                f["frameColor"] = (
                    0.55 + 0.35 * glow,
                    0.1 + 0.6 * glow,
                    0.8,
                    0.92
                )
            elif not (self.active_is_black and i == self.active_key_idx):
                f["frameColor"] = (0.55, 0.1, 0.8, 0.92)

        return task.cont

    # ====================================================
    # UPDATE — CALLED EACH FRAME FROM MAIN
    # ====================================================

    def update(self, hand):
        if hand is None:
            self._reset_all_keys()
            self.active_key_idx = None
            return

        lm = hand.landmark
        index_tip = lm[8]

        # Normalized screen coordinates
        fx = index_tip.x   # 0 = left edge, 1 = right edge
        fy = index_tip.y   # 0 = top, 1 = bottom (camera coords)

        # Map to aspect2d X space
        screen_x = (fx - 0.5) * 3.54  # approx range -1.77 to +1.77

        # Y zone: finger must be in the key region (vertically)
        # Key strip center is around z=-0.18, height ~0.55, so z range [-0.455, 0.095]
        # In camera Y: y ranges 0-1, center at 0.5 is z~0
        # Accept any Y — the X mapping is what drives the note
        # (user just moves left-right along the key strip)

        # Determine if over a black key first (priority)
        hit_black = None
        for i, bx in enumerate(self.black_key_x):
            hw = 0.055  # half-width of black key in screen X
            if abs(screen_x - bx) <= hw:
                hit_black = i
                break

        if hit_black is not None:
            self._highlight_black(hit_black)
            self.active_key_idx = hit_black
            self.active_is_black = True
            note_label = self.BLACK_KEYS[hit_black]["label"]
            note_id = self.BLACK_KEYS[hit_black]["note"]
            self._trigger_note(f"black_{note_id}", note_id, note_label, is_black=True)
        else:
            # White key
            hit_white = None
            key_w = self.white_key_w + 0.015
            for i, wx in enumerate(self.white_key_x):
                hw = key_w / 2.0
                if abs(screen_x - wx) <= hw:
                    hit_white = i
                    break

            if hit_white is not None:
                self._highlight_white(hit_white)
                self.active_key_idx = hit_white
                self.active_is_black = False
                note_label = self.WHITE_KEYS[hit_white]
                note_id = note_label.replace("5", "")  # "C5" -> "C"
                self._trigger_note(f"white_{hit_white}", note_id, note_label, is_black=False)
            else:
                # Not over any key — finger outside piano range
                self.active_key_idx = None
                self._reset_all_keys()

    def _trigger_note(self, key_id, note_id, label, is_black):
        now = time.time()
        if note_id != self.last_note or (now - self.last_time > self.cooldown):
            self.last_note = note_id
            self.last_time = now
            self.key_glow_timers[key_id] = now

            # Play via sound manager
            if hasattr(self.sound_manager, "play_piano"):
                self.sound_manager.play_piano(note_id)

            sym = "#" if is_black else "*"
            self.note_display["text"] = f"{sym}  PLAYING:  [ {label} ]  {sym}"
            self.note_display["text_fg"] = Vec4(0.2, 1.0, 0.6, 1.0)

    def _highlight_white(self, idx):
        for i, f in enumerate(self.white_key_frames):
            if i == idx:
                f["frameColor"] = (0.15, 0.55, 1.0, 0.98)
                self.white_key_labels[i]["text_fg"] = Vec4(1.0, 1.0, 1.0, 1.0)
            else:
                f["frameColor"] = (0.04, 0.12, 0.24, 0.82)
                self.white_key_labels[i]["text_fg"] = Vec4(0.7, 0.9, 1.0, 1.0)
        for f in self.black_key_frames:
            f["frameColor"] = (0.55, 0.1, 0.8, 0.92)

    def _highlight_black(self, idx):
        for i, f in enumerate(self.black_key_frames):
            if i == idx:
                f["frameColor"] = (1.0, 0.5, 1.0, 1.0)
                self.black_key_labels[i]["text_fg"] = Vec4(1.0, 1.0, 1.0, 1.0)
            else:
                f["frameColor"] = (0.55, 0.1, 0.8, 0.92)
                self.black_key_labels[i]["text_fg"] = Vec4(0.95, 0.9, 1.0, 1.0)
        for f in self.white_key_frames:
            f["frameColor"] = (0.04, 0.12, 0.24, 0.82)

    def _reset_all_keys(self):
        for f, l in zip(self.white_key_frames, self.white_key_labels):
            f["frameColor"] = (0.04, 0.12, 0.24, 0.82)
            l["text_fg"] = Vec4(0.7, 0.9, 1.0, 1.0)
        for f, l in zip(self.black_key_frames, self.black_key_labels):
            f["frameColor"] = (0.55, 0.1, 0.8, 0.92)
            l["text_fg"] = Vec4(0.95, 0.9, 1.0, 1.0)

    def show(self):
        self.frame.show()
        if hasattr(self, 'piano_world'):
            self.piano_world.show()

    def hide(self):
        self.frame.hide()
        if hasattr(self, 'piano_world'):
            self.piano_world.hide()
        self._reset_all_keys()

    def cleanup(self):
        self._alive = False
        try:
            self.base.taskMgr.remove("PianoAnimation")
        except Exception:
            pass
        try:
            if hasattr(self, 'piano_world'):
                self.piano_world.removeNode()
        except Exception:
            pass
        try:
            self.frame.destroy()
        except Exception:
            pass