import math
import time
from panda3d.core import (
    NodePath, Point3, Vec3, Vec4,
    GeomVertexFormat, GeomVertexData, GeomVertexWriter,
    Geom, GeomTriangles, GeomNode,
    Material, TransparencyAttrib, AntialiasAttrib,
    LineSegs
)


class HandModel:
    """
    Volumetric 3D Holographic Hand for HoloHand AI.
    Features:
      - Fully enclosed 3D volumetric palm hull with palmar/dorsal curvature & side walls.
      - 15 anatomical tapered finger segments (phalanges) with smooth orientation.
      - 21 rounded volumetric knuckle and joint nodes.
      - 5 pulsating holographic fingertip energy beacons.
      - Tapered cyber wrist & forearm collar anchor.
      - Internal holographic cyber-filament neural lines.
      - Smooth adaptive velocity-based EMA filtering (zero jitter, zero lag).
      - Graceful canonical idle/standby hovering pose when no hand is in view.
    """

    # Anatomical finger bones: (parent_landmark, child_landmark)
    FINGER_BONES = [
        # Thumb: metacarpal, proximal, distal
        (1, 2), (2, 3), (3, 4),
        # Index: proximal, intermediate, distal
        (5, 6), (6, 7), (7, 8),
        # Middle: proximal, intermediate, distal
        (9, 10), (10, 11), (11, 12),
        # Ring: proximal, intermediate, distal
        (13, 14), (14, 15), (15, 16),
        # Pinky: proximal, intermediate, distal
        (17, 18), (18, 19), (19, 20),
    ]

    # Palm perimeter landmarks forming the volumetric hand base
    PALM_PERIMETER = [0, 1, 5, 9, 13, 17]

    FINGERTIPS = [4, 8, 12, 16, 20]
    KNUCKLES = [5, 9, 13, 17]

    # Anatomical radii for joint spheres (scene units)
    JOINT_RADII = {
        0: 0.110,   # Wrist
        1: 0.080,   # Thumb CMC
        2: 0.075,   # Thumb MCP
        3: 0.065,   # Thumb IP
        4: 0.055,   # Thumb tip
        5: 0.080,   # Index MCP (knuckle)
        6: 0.068,   # Index PIP
        7: 0.058,   # Index DIP
        8: 0.048,   # Index tip
        9: 0.082,   # Middle MCP
        10: 0.070,  # Middle PIP
        11: 0.060,  # Middle DIP
        12: 0.050,  # Middle tip
        13: 0.076,  # Ring MCP
        14: 0.065,  # Ring PIP
        15: 0.055,  # Ring DIP
        16: 0.046,  # Ring tip
        17: 0.070,  # Pinky MCP
        18: 0.058,  # Pinky PIP
        19: 0.048,  # Pinky DIP
        20: 0.042,  # Pinky tip
    }

    # Anatomical thickness for bone segments
    BONE_THICKNESS = {
        (1, 2): (0.075, 0.070),
        (2, 3): (0.070, 0.062),
        (3, 4): (0.060, 0.050),
        (5, 6): (0.074, 0.064),
        (6, 7): (0.064, 0.054),
        (7, 8): (0.052, 0.044),
        (9, 10): (0.076, 0.066),
        (10, 11): (0.066, 0.056),
        (11, 12): (0.054, 0.046),
        (13, 14): (0.070, 0.060),
        (14, 15): (0.060, 0.052),
        (15, 16): (0.050, 0.042),
        (17, 18): (0.064, 0.054),
        (18, 19): (0.054, 0.046),
        (19, 20): (0.044, 0.038),
    }

    def __init__(self, base):
        self.base = base
        self.root = NodePath("HoloHand3D_Root")
        self.root.reparentTo(self.base.render)
        self.root.setTransparency(TransparencyAttrib.MAlpha)
        self.root.setAntialias(AntialiasAttrib.MAuto)

        # Dynamic state
        self.is_tracking = False
        self.pulse_phase = 0.0
        self.idle_phase = 0.0
        self.standby_blend = 1.0  # 1.0 = full idle pose, 0.0 = live hand
        self.smoothed_points = None
        self.previous_raw = None

        # Materials
        self._init_materials()

        # Shared procedural geometry prototypes
        self._sphere_proto = self._build_sphere_proto(slices=12, stacks=10)
        self._cylinder_proto = self._build_cylinder_proto(slices=12)

        # Build permanent scene graph hierarchy (no per-frame destruction!)
        self._build_scene_graph()

        # Precompute canonical resting idle hand pose
        self.idle_landmarks = self._create_canonical_idle_landmarks()

    # ==================================================================
    # MATERIALS & VISUAL SHADING
    # ==================================================================

    def _init_materials(self):
        # 1. Translucent Volumetric Palm Material (Cyan / Electric Blue)
        self.palm_mat = Material("HoloPalmMat")
        self.palm_mat.setAmbient(Vec4(0.04, 0.22, 0.40, 0.85))
        self.palm_mat.setDiffuse(Vec4(0.10, 0.72, 0.95, 0.82))
        self.palm_mat.setSpecular(Vec4(0.85, 0.98, 1.0, 1.0))
        self.palm_mat.setShininess(75)
        self.palm_mat.setEmission(Vec4(0.02, 0.16, 0.28, 1.0))

        # 2. Finger Bone Segment Material (Sleek Translucent Cyan)
        self.bone_mat = Material("HoloBoneMat")
        self.bone_mat.setAmbient(Vec4(0.05, 0.25, 0.42, 0.88))
        self.bone_mat.setDiffuse(Vec4(0.12, 0.80, 1.0, 0.88))
        self.bone_mat.setSpecular(Vec4(0.9, 1.0, 1.0, 1.0))
        self.bone_mat.setShininess(85)
        self.bone_mat.setEmission(Vec4(0.03, 0.20, 0.32, 1.0))

        # 3. Knuckle & Joint Material (Cyber Violet / Electric Cyan Accent)
        self.joint_mat = Material("HoloJointMat")
        self.joint_mat.setAmbient(Vec4(0.15, 0.12, 0.35, 0.92))
        self.joint_mat.setDiffuse(Vec4(0.55, 0.35, 0.95, 0.92))
        self.joint_mat.setSpecular(Vec4(0.9, 0.8, 1.0, 1.0))
        self.joint_mat.setShininess(90)
        self.joint_mat.setEmission(Vec4(0.20, 0.08, 0.38, 1.0))

        # 4. Fingertip Energy Core Material (High-Luminance Beacon)
        self.beacon_mat = Material("HoloBeaconMat")
        self.beacon_mat.setAmbient(Vec4(0.2, 0.6, 0.8, 1.0))
        self.beacon_mat.setDiffuse(Vec4(0.4, 0.95, 1.0, 1.0))
        self.beacon_mat.setSpecular(Vec4(1.0, 1.0, 1.0, 1.0))
        self.beacon_mat.setShininess(128)
        self.beacon_mat.setEmission(Vec4(0.3, 0.85, 1.0, 1.0))

        # 5. Wrist Forearm Collar Material
        self.cuff_mat = Material("HoloCuffMat")
        self.cuff_mat.setAmbient(Vec4(0.03, 0.18, 0.32, 0.80))
        self.cuff_mat.setDiffuse(Vec4(0.08, 0.55, 0.85, 0.78))
        self.cuff_mat.setSpecular(Vec4(0.7, 0.9, 1.0, 1.0))
        self.cuff_mat.setShininess(60)
        self.cuff_mat.setEmission(Vec4(0.02, 0.12, 0.22, 1.0))

    # ==================================================================
    # PROCEDURAL GEOMETRY BUILDERS
    # ==================================================================

    def _build_sphere_proto(self, slices=12, stacks=10):
        """Creates a smooth unit sphere prototype centered at (0, 0, 0)."""
        fmt = GeomVertexFormat.getV3n3()
        vdata = GeomVertexData("sphere_proto", fmt, Geom.UHStatic)
        vwriter = GeomVertexWriter(vdata, "vertex")
        nwriter = GeomVertexWriter(vdata, "normal")
        tris = GeomTriangles(Geom.UHStatic)

        for i in range(stacks + 1):
            phi = math.pi * i / stacks
            sin_p = math.sin(phi)
            cos_p = math.cos(phi)
            for j in range(slices + 1):
                theta = 2.0 * math.pi * j / slices
                x = sin_p * math.cos(theta)
                y = sin_p * math.sin(theta)
                z = cos_p
                vwriter.addData3(x, y, z)
                nwriter.addData3(x, y, z)

        for i in range(stacks):
            for j in range(slices):
                a = i * (slices + 1) + j
                b = a + slices + 1
                tris.addVertices(a, b, a + 1)
                tris.addVertices(a + 1, b, b + 1)

        geom = Geom(vdata)
        geom.addPrimitive(tris)
        node = GeomNode("sphere_geom")
        node.addGeom(geom)
        return node

    def _build_cylinder_proto(self, slices=12):
        """Creates a smooth unit cylinder prototype along +Z from z=0 to z=1."""
        fmt = GeomVertexFormat.getV3n3()
        vdata = GeomVertexData("cyl_proto", fmt, Geom.UHStatic)
        vwriter = GeomVertexWriter(vdata, "vertex")
        nwriter = GeomVertexWriter(vdata, "normal")
        tris = GeomTriangles(Geom.UHStatic)

        # 2 rings: z = 0 and z = 1
        for ring in (0.0, 1.0):
            for i in range(slices):
                theta = 2.0 * math.pi * i / slices
                x = math.cos(theta)
                y = math.sin(theta)
                vwriter.addData3(x, y, ring)
                nwriter.addData3(x, y, 0.0)

        # Side quads
        for i in range(slices):
            i_next = (i + 1) % slices
            b0 = i
            t0 = i + slices
            b1 = i_next
            t1 = i_next + slices
            tris.addVertices(b0, t0, b1)
            tris.addVertices(b1, t0, t1)

        geom = Geom(vdata)
        geom.addPrimitive(tris)
        node = GeomNode("cyl_geom")
        node.addGeom(geom)
        return node

    # ==================================================================
    # SCENE GRAPH INITIALIZATION
    # ==================================================================

    def _build_scene_graph(self):
        """Constructs permanent scene graph nodes to avoid garbage collection spikes."""
        # 1. Palm Node (Volumetric Dynamic Mesh attached here)
        self.palm_np = self.root.attachNewNode(GeomNode("palm_mesh_node"))
        self.palm_np.setMaterial(self.palm_mat, 1)
        self.palm_np.setTwoSided(True)

        # 2. Forearm Wrist Cuff Node
        self.cuff_np = self.root.attachNewNode(self._cylinder_proto)
        self.cuff_np.setMaterial(self.cuff_mat, 1)

        # 3. Bone Segments (15 cylinders)
        self.bone_nodes = {}
        for parent_idx, child_idx in self.FINGER_BONES:
            key = (parent_idx, child_idx)
            np = self.root.attachNewNode(self._cylinder_proto)
            np.setMaterial(self.bone_mat, 1)
            self.bone_nodes[key] = np

        # 4. Joint Spheres (21 spheres)
        self.joint_nodes = {}
        for i in range(21):
            np = self.root.attachNewNode(self._sphere_proto)
            # Fingertips get high-luminance beacon material, others get joint material
            if i in self.FINGERTIPS:
                np.setMaterial(self.beacon_mat, 1)
            else:
                np.setMaterial(self.joint_mat, 1)
            self.joint_nodes[i] = np

        # 5. Internal Cyber Filament NodePath (for holographic depth)
        self.filament_np = self.root.attachNewNode(GeomNode("filaments"))

    # ==================================================================
    # CANONICAL IDLE HAND POSE
    # ==================================================================

    def _create_canonical_idle_landmarks(self):
        """Returns standard 21 3D points representing a relaxed, elegant hovering hand."""
        # Proportions derived from natural resting hand posture
        pts = {}
        # Wrist at origin
        pts[0] = Point3(0.0, 0.0, -1.1)

        # Thumb (gently angled outward)
        pts[1] = Point3(-0.45, 0.05, -0.75)
        pts[2] = Point3(-0.78, 0.12, -0.42)
        pts[3] = Point3(-0.95, 0.18, -0.15)
        pts[4] = Point3(-1.08, 0.22, 0.08)

        # Index (relaxed slight curl)
        pts[5] = Point3(-0.42, 0.05, -0.05)
        pts[6] = Point3(-0.46, 0.10, 0.42)
        pts[7] = Point3(-0.48, 0.18, 0.78)
        pts[8] = Point3(-0.49, 0.26, 1.05)

        # Middle (central tall finger, gentle curl)
        pts[9] = Point3(-0.02, 0.02, 0.02)
        pts[10] = Point3(-0.03, 0.08, 0.52)
        pts[11] = Point3(-0.04, 0.17, 0.92)
        pts[12] = Point3(-0.05, 0.27, 1.22)

        # Ring (relaxed curl)
        pts[13] = Point3(0.38, 0.00, -0.06)
        pts[14] = Point3(0.40, 0.07, 0.44)
        pts[15] = Point3(0.42, 0.16, 0.80)
        pts[16] = Point3(0.43, 0.25, 1.08)

        # Pinky (relaxed curl)
        pts[17] = Point3(0.74, -0.04, -0.18)
        pts[18] = Point3(0.79, 0.04, 0.22)
        pts[19] = Point3(0.82, 0.12, 0.52)
        pts[20] = Point3(0.84, 0.20, 0.76)

        return [pts[i] for i in range(21)]

    # ==================================================================
    # VOLUMETRIC PALM PROCEDURAL MESH
    # ==================================================================

    def _update_volumetric_palm(self, points):
        """
        Builds a completely enclosed, 3D volumetric hull for the palm:
        - Front palmar face (natural inward cup)
        - Back dorsal face (natural knuckle curvature)
        - Side perimeter walls joining front and back
        """
        p0 = points[0]    # Wrist
        p1 = points[1]    # Thumb base
        p5 = points[5]    # Index MCP
        p9 = points[9]    # Middle MCP
        p13 = points[13]  # Ring MCP
        p17 = points[17]  # Pinky MCP

        # Compute palm center
        center_x = (p0.getX() + p5.getX() + p9.getX() + p13.getX() + p17.getX()) * 0.2
        center_y = (p0.getY() + p5.getY() + p9.getY() + p13.getY() + p17.getY()) * 0.2
        center_z = (p0.getZ() + p5.getZ() + p9.getZ() + p13.getZ() + p17.getZ()) * 0.2
        p_center = Point3(center_x, center_y, center_z)

        # Palm directional & lateral vectors
        dir_vec = Vec3(p9.getX() - p0.getX(), p9.getY() - p0.getY(), p9.getZ() - p0.getZ())
        lat_vec = Vec3(p5.getX() - p17.getX(), p5.getY() - p17.getY(), p5.getZ() - p17.getZ())
        norm_vec = dir_vec.cross(lat_vec)
        if norm_vec.lengthSquared() > 0.0001:
            norm_vec.normalize()
        else:
            norm_vec = Vec3(0, -1, 0)

        # Anatomical palm thickness per landmark
        thickness_map = {
            0: 0.12,   # Wrist
            1: 0.14,   # Thenar eminence (thumb pad)
            5: 0.085,  # Index knuckle
            9: 0.090,  # Middle knuckle
            13: 0.085, # Ring knuckle
            17: 0.075, # Pinky knuckle
        }
        center_thickness = 0.10

        # Construct Front (palmar) and Back (dorsal) offset points
        perim_indices = [0, 1, 5, 9, 13, 17]
        front_pts = []
        back_pts = []
        for idx in perim_indices:
            p = points[idx]
            th = thickness_map[idx] * 0.5
            front_pts.append(Point3(p.getX() + norm_vec.getX() * th,
                                    p.getY() + norm_vec.getY() * th,
                                    p.getZ() + norm_vec.getZ() * th))
            back_pts.append(Point3(p.getX() - norm_vec.getX() * th,
                                   p.getY() - norm_vec.getY() * th,
                                   p.getZ() - norm_vec.getZ() * th))

        # Center points
        th_c = center_thickness * 0.5
        c_front = Point3(p_center.getX() + norm_vec.getX() * th_c,
                         p_center.getY() + norm_vec.getY() * th_c,
                         p_center.getZ() + norm_vec.getZ() * th_c)
        c_back = Point3(p_center.getX() - norm_vec.getX() * th_c,
                        p_center.getY() - norm_vec.getY() * th_c,
                        p_center.getZ() - norm_vec.getZ() * th_c)

        # Build Geom with dynamic vertex data
        fmt = GeomVertexFormat.getV3n3()
        vdata = GeomVertexData("palm_vdata", fmt, Geom.UHDynamic)
        vwriter = GeomVertexWriter(vdata, "vertex")
        nwriter = GeomVertexWriter(vdata, "normal")
        tris = GeomTriangles(Geom.UHDynamic)

        vert_count = 0

        def add_tri(v1, v2, v3, n):
            nonlocal vert_count
            vwriter.addData3(v1)
            nwriter.addData3(n)
            vwriter.addData3(v2)
            nwriter.addData3(n)
            vwriter.addData3(v3)
            nwriter.addData3(n)
            tris.addVertices(vert_count, vert_count + 1, vert_count + 2)
            vert_count += 3

        num_perim = len(perim_indices)

        # 1. Front (Palmar) Triangles (Fan around c_front)
        front_norm = norm_vec
        for i in range(num_perim):
            i_next = (i + 1) % num_perim
            add_tri(c_front, front_pts[i], front_pts[i_next], front_norm)

        # 2. Back (Dorsal) Triangles (Fan around c_back with reversed winding)
        back_norm = -norm_vec
        for i in range(num_perim):
            i_next = (i + 1) % num_perim
            add_tri(c_back, back_pts[i_next], back_pts[i], back_norm)

        # 3. Side Boundary Walls (Quads joining front and back perimeters)
        for i in range(num_perim):
            i_next = (i + 1) % num_perim
            fa = front_pts[i]
            fb = front_pts[i_next]
            ba = back_pts[i]
            bb = back_pts[i_next]

            # Compute quad wall normal
            edge_v = Vec3(fb.getX() - fa.getX(), fb.getY() - fa.getY(), fb.getZ() - fa.getZ())
            depth_v = Vec3(ba.getX() - fa.getX(), ba.getY() - fa.getY(), ba.getZ() - fa.getZ())
            wall_n = edge_v.cross(depth_v)
            if wall_n.lengthSquared() > 0.0001:
                wall_n.normalize()
            else:
                wall_n = front_norm

            add_tri(fa, fb, bb, wall_n)
            add_tri(fa, bb, ba, wall_n)

        geom = Geom(vdata)
        geom.addPrimitive(tris)

        gn = self.palm_np.node()
        gn.removeAllGeoms()
        gn.addGeom(geom)

    # ==================================================================
    # INTERNAL NEURAL FILAMENTS
    # ==================================================================

    def _update_neural_filaments(self, points):
        """Draws thin glowing internal cyber filaments connecting the joint network."""
        lines = LineSegs("filaments")
        lines.setThickness(1.4)
        lines.setColor(0.2, 0.85, 1.0, 0.45)

        # Connections from wrist to knuckles
        p0 = points[0]
        for k in (1, 5, 9, 13, 17):
            lines.moveTo(p0)
            lines.drawTo(points[k])

        # Knuckle arch
        lines.moveTo(points[5])
        lines.drawTo(points[9])
        lines.drawTo(points[13])
        lines.drawTo(points[17])

        # Finger bone lines
        for start_i, end_i in self.FINGER_BONES:
            lines.moveTo(points[start_i])
            lines.drawTo(points[end_i])

        if hasattr(self, 'filament_np') and not self.filament_np.isEmpty():
            self.filament_np.removeNode()
        self.filament_np = self.root.attachNewNode(lines.create())

    # ==================================================================
    # TRANSFORM UPDATE (BONES, JOINTS, CUFF)
    # ==================================================================

    def _update_transforms(self, points):
        """Updates positions and orientations of pre-allocated nodes efficiently."""
        # 1. Update Joint Spheres
        pulse_factor = 0.5 + 0.5 * math.sin(self.pulse_phase)
        for i in range(21):
            np = self.joint_nodes[i]
            np.setPos(points[i])
            r = self.JOINT_RADII.get(i, 0.05)
            if i in self.FINGERTIPS:
                # Pulsing beacon size
                pulsed_r = r * (1.0 + 0.22 * pulse_factor)
                np.setScale(pulsed_r)
            else:
                np.setScale(r)

        # 2. Update Finger Bone Cylinders
        for (parent_idx, child_idx), np in self.bone_nodes.items():
            p1 = points[parent_idx]
            p2 = points[child_idx]
            dx = p2.getX() - p1.getX()
            dy = p2.getY() - p1.getY()
            dz = p2.getZ() - p1.getZ()
            length = math.sqrt(dx * dx + dy * dy + dz * dz)

            if length < 0.005:
                np.setScale(0.001)
                continue

            r_base, r_tip = self.BONE_THICKNESS.get((parent_idx, child_idx), (0.05, 0.04))
            avg_r = (r_base + r_tip) * 0.5

            np.setPos(p1)
            np.lookAt(Point3(p2.getX(), p2.getY(), p2.getZ()))
            # Panda3D lookAt points +Y at target; unit cylinder is along +Z, rotate -90 Pitch
            np.setHpr(np.getH(), np.getP() - 90, np.getR())
            np.setScale(avg_r, avg_r, length)

        # 3. Update Wrist Forearm Cuff
        p_wrist = points[0]
        p_middle_mcp = points[9]
        # Direction vector from wrist to palm
        v_palm = Vec3(p_middle_mcp.getX() - p_wrist.getX(),
                      p_middle_mcp.getY() - p_wrist.getY(),
                      p_middle_mcp.getZ() - p_wrist.getZ())
        if v_palm.lengthSquared() > 0.001:
            v_palm.normalize()
        else:
            v_palm = Vec3(0, 0, 1)

        # Forearm extends backward along -v_palm
        cuff_length = 0.55
        p_forearm_end = Point3(
            p_wrist.getX() - v_palm.getX() * cuff_length,
            p_wrist.getY() - v_palm.getY() * cuff_length,
            p_wrist.getZ() - v_palm.getZ() * cuff_length
        )
        self.cuff_np.setPos(p_forearm_end)
        self.cuff_np.lookAt(Point3(p_wrist.getX(), p_wrist.getY(), p_wrist.getZ()))
        self.cuff_np.setHpr(self.cuff_np.getH(), self.cuff_np.getP() - 90, self.cuff_np.getR())
        self.cuff_np.setScale(0.125, 0.125, cuff_length)

    # ==================================================================
    # MAIN UPDATE PIPELINE
    # ==================================================================

    def update(self, hand):
        """
        Main per-frame update:
        - If hand is detected: extracts 3D points, applies velocity-adaptive EMA smoothing,
          and renders the live tracked hand.
        - If no hand is detected: smoothly animates in a calm, hovering canonical idle pose.
        """
        dt = 0.016
        if hasattr(self.base, 'taskMgr'):
            dt = globalClock.getDt() if 'globalClock' in globals() else 0.016  # noqa

        self.pulse_phase = (self.pulse_phase + dt * 4.2) % (math.pi * 2)
        self.idle_phase = (self.idle_phase + dt * 1.5) % (math.pi * 2)

        if hand is not None:
            self.is_tracking = True
            # Blend smoothly towards live tracked pose
            self.standby_blend = max(0.0, self.standby_blend - dt * 4.0)

            # 1. Transform raw camera landmarks into calibrated 3D space
            # Landmark scale normalization (wrist to middle knuckle image distance)
            wrist = hand.landmark[0]
            knuckle = hand.landmark[9]
            dx = (knuckle.x - wrist.x)
            dy = (knuckle.y - wrist.y)
            dz = (knuckle.z - wrist.z)
            palm_scale = math.sqrt(dx * dx + dy * dy + dz * dz)
            if palm_scale < 0.05:
                palm_scale = 0.18

            # Depth factor: hand closer to camera (larger palm_scale) moves forward
            depth_offset = (palm_scale - 0.20) * 8.0

            raw_points = []
            for lm in hand.landmark:
                # Mirrored X for natural user feedback: +X is right, -X is left
                x = (lm.x - 0.5) * 7.2
                # +Z is up, -Z is down
                z = (0.5 - lm.y) * 5.6
                # +Y is depth into the screen
                y = 1.8 - (lm.z * 6.5) - depth_offset
                raw_points.append(Point3(x, y, z))

            # 2. Adaptive Exponential Moving Average (EMA)
            if self.smoothed_points is None:
                self.smoothed_points = [Point3(p) for p in raw_points]
            else:
                for i in range(21):
                    cur = self.smoothed_points[i]
                    tgt = raw_points[i]
                    dist = (tgt - cur).length()
                    # Adaptive factor: high velocity -> responsive (0.85); still -> ultra-smooth (0.35)
                    alpha = min(0.85, max(0.35, dist * 2.2))
                    self.smoothed_points[i] = Point3(
                        cur.getX() + (tgt.getX() - cur.getX()) * alpha,
                        cur.getY() + (tgt.getY() - cur.getY()) * alpha,
                        cur.getZ() + (tgt.getZ() - cur.getZ()) * alpha
                    )

            target_points = self.smoothed_points

        else:
            self.is_tracking = False
            # Blend smoothly towards canonical idle standby pose
            self.standby_blend = min(1.0, self.standby_blend + dt * 2.5)

            # Canonical idle pose with gentle hovering breathing oscillation
            hover_z = math.sin(self.idle_phase) * 0.12
            hover_y = math.cos(self.idle_phase * 0.7) * 0.08
            hover_roll = math.sin(self.idle_phase * 0.5) * 0.04

            idle_pts = []
            for pt in self.idle_landmarks:
                # Positioned centrally in the holographic interaction volume
                px = pt.getX() + hover_roll * pt.getZ()
                py = pt.getY() + 1.8 + hover_y
                pz = pt.getZ() + 0.3 + hover_z
                idle_pts.append(Point3(px, py, pz))

            if self.smoothed_points is None:
                self.smoothed_points = [Point3(p) for p in idle_pts]
            else:
                # Smoothly interpolate towards idle pose
                blend_speed = 0.12
                for i in range(21):
                    cur = self.smoothed_points[i]
                    tgt = idle_pts[i]
                    self.smoothed_points[i] = Point3(
                        cur.getX() + (tgt.getX() - cur.getX()) * blend_speed,
                        cur.getY() + (tgt.getY() - cur.getY()) * blend_speed,
                        cur.getZ() + (tgt.getZ() - cur.getZ()) * blend_speed
                    )

            target_points = self.smoothed_points

        # 3. Render 3D Volumetric Hand
        self._update_volumetric_palm(target_points)
        self._update_transforms(target_points)
        self._update_neural_filaments(target_points)

    # ==================================================================
    # CLEANUP & VISIBILITY
    # ==================================================================

    def clear(self):
        """Smoothly resets to idle state rather than abruptly disappearing."""
        self.is_tracking = False
        self.smoothed_points = None

    def hide(self):
        self.root.hide()

    def show(self):
        self.root.show()

    def cleanup(self):
        try:
            self.root.removeNode()
        except Exception:
            pass